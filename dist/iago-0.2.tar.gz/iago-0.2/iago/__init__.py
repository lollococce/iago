# import submodules you want to install

from .iago import *

__docformat__ = "restructuredtext"


# module level doc-string
__doc__ = """
iago - a powerful speech recognition library for Python
=====================================================================

**iago** is a Python package providing many different useful functions
for speech recognition and text to speech

Main Features
-------------
Here are just a few of the things that iago does well:

  - TODO
"""
